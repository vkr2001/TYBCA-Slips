# Q1.Write a R program to add, multiply and divide two vectors of integertype. (Vector
# length should be minimum 4) 

# Define two integer vectors
vector1 <- c(1, 2, 3, 4)
vector2 <- c(5, 6, 7, 8)

# Addition
addition_result <- vector1 + vector2
print("Addition Result:")
print(addition_result)

# Multiplication
multiplication_result <- vector1 * vector2
print("Multiplication Result:")
print(multiplication_result)

# Division
division_result <- vector1 / vector2
print("Division Result:")
print(division_result)