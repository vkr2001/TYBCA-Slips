# Q1. Write a R program to find the maximum and the minimum value of a givenvector [10
# Marks]

# Create a vector
my_vector <- c(12, 34, 5, 23, 9, 2, 45, 8, 31)

# Find the maximum value
max_value <- max(my_vector)

# Find the minimum value
min_value <- min(my_vector)

# Print the maximum and minimum values
cat("Maximum value:", max_value, "\n")
cat("Minimum value:", min_value, "\n")
