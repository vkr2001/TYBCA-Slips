# Q1. Write a R program to find the maximum and the minimum value of a givenvector

# Create a vector
my_vector <- c(34, 56, 12, 98, 23, 45, 67)

# Find the maximum and minimum values
max_value <- max(my_vector)
min_value <- min(my_vector)

# Print the maximum and minimum values
cat("Maximum Value:", max_value, "\n")
cat("Minimum Value:", min_value, "\n")
